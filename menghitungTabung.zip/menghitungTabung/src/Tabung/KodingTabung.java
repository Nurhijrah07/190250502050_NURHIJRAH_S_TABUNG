/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tabung;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Nh07
 */
public class KodingTabung {
    public static void main(String[] args) {
        BufferedReader dataIn = new BufferedReader (new InputStreamReader(System.in));
        formulaTabung Tabung = new formulaTabung();
    try
    {
        System.out.println("Masukkan nilai Tinggi :");
        String t = dataIn.readLine();
        Tabung.setTinggi(Integer.parseInt(t));
        
        System.out.println("Masukkan nilai jari-jari :");
        String r = dataIn.readLine();
        Tabung.setJari(Integer.parseInt(r));
        
        System.out.println("Tinggi Tabung ="+Tabung.getTinggi());
        System.out.println("Jari Tabung ="+ Tabung.getJari());
        System.out.println("luas 7Tabung ="+ Tabung.hitungLuasAlas());
        System.out.println("Volume Tabung ="+ Tabung.hitungVolume());
        System.out.println("Keliling Tabung ="+ Tabung.hitungKelilingLingkaranAlasatauTutup());
    }    
        catch (IOException e)
    {
        System.out.println("Error");
    }
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tabung;

/**
 *
 * @author Nh07
 */
public class formulaTabung {
    private int tinggi;
    private int Jari;
    
    public void setTinggi(int tinggi)
{
    this.tinggi = tinggi;
}
    public void setJari (int jari)
{
    this.Jari = jari;
}
    public int getTinggi()
{
    return tinggi;
}
    public int getJari()
{
    return Jari;
}
    public double hitungLuasAlas()
{
    double luas;
    luas = 3.14*Jari*2;
    return luas;
}
    public double hitungVolume()
{
    double Volume;
    Volume = 3.14*Jari*2*tinggi;
    return Volume;
}
    public double hitungKelilingLingkaranAlasatauTutup()
{
    double keliling;
    keliling = 2*3.14*Jari;
    return keliling;

}
    
}
